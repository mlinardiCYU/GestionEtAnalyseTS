# Haptics

Data are taken from 5 people entering their passgraph (a code to access a system protected by a graphical authentication system) on a touchscreen. The data are the x-axis movement only.

Train size: 155

Test size: 308

Missing value: No

Number of classses: 5

Time series length: 1092

Data donated by Jill Brady (see [1]).

[1] http://www.timeseriesclassification.com/description.php?Dataset=Haptics